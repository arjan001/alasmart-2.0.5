<?php

return [
    'name' => 'Subscription'
];
