<?php
 return array (
  'Country code is required' => 'Country code is required',
  'Country code already exist' => 'Country code already exist',
  'Currency code is required' => 'Currency code is required',
  'Currency code already exist' => 'Currency code already exist',
  'You can not delete this currency. Because there are one or more payment method has been created in this currency.' => 'You can not delete this currency. Because there are one or more payment method has been created in this currency.',

  'Currency is required' => 'Currency is required',
  'Public key is required' => 'Public key is required',
  'Secret key is required' => 'Secret key is required',
  'Webhook is required' => 'Webhook is required',
  'API key is required' => 'API key is required',
  'Public key is required' => 'Public key is required',
  'Access token is required' => 'Access token is required',

  'Plan name is required' => 'Plan name is required',
  'Plan price is required' => 'Plan price is required',
  'Expiration date is required' => 'Expiration date is required',
  'Maximum service is required' => 'Maximum service is required',
  'Serial is required' => 'Serial is required',
  'Plan is required' => 'Plan is required',
  'Provider is required' => 'Provider is required',
  'Assign Successfully' => 'Assign Successfully',
  'Approved Successfully' => 'Approved Successfully',
);
