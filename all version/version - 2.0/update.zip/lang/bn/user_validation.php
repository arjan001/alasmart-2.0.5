<?php
 return array (
  'Enrolled Successfully' => 'Enrolled Successfully',
  'You have already enrolled trail version' => 'You have already enrolled trail version',
  'Client id is required' => 'Client id is required',
  'Secret id is required' => 'Secret id is required',
  'Data Save successfully' => 'Data Save successfully',
  'Publishable key is required' => 'Publishable key is required',
  'Secret key is required' => 'Secret key is required',
  'Key is required' => 'Key is required',
  'Secret key is required' => 'Secret key is required',
  'Public key is required' => 'Public key is required',
  'Secret key is required' => 'Secret key is required',
  'Mollie key is required' => 'Mollie key is required',
  'Api key is required' => 'Api key is required',
  'Auth token is required' => 'Auth token is required',
  'Bank instruction is required' => 'Bank instruction is required',
  'At a time, you should not buy products from multiple authors.' => 'At a time, you should not buy products from multiple authors.',
  'Not Found any Subscription Plan' => 'Not Found any Subscription Plan',
  'Pls Upgrade your Subscription Plan' => 'Pls Upgrade your Subscription Plan',
  "This Product dosen't have any variant" => "This Product dosen't have any variant",
);
 ?>
