<?php
 return array (

  'Plan name is required' => 'Plan name is required',
  'Plan price is required' => 'Plan price is required',
  'Expiration date is required' => 'Expiration date is required',
  'Maximum service is required' => 'Maximum service is required',
  'Serial is required' => 'Serial is required',
  'Plan is required' => 'Plan is required',
  'Provider is required' => 'Provider is required',
  'Assign Successfully' => 'Assign Successfully',
  'Approved Successfully' => 'Approved Successfully',
);
