<?php
 return array (
  'Gateway Information' => 'Gateway Information',
  'Paymongo Information' => 'Paymongo Information',
  'Iyzico Information' => 'Iyzico Information',
  'Paymongo Image' => 'Paymongo Image',
  'Grabpay Image' => 'Grabpay Image',
  'GCash Image' => 'GCash Image',
  'Webhook Sig' => 'Webhook Sig',
  'Iyzico Image' => 'Iyzico Image',
  'API Key' => 'API Key',
  'Public Key' => 'Public Key',
  'Access token' => 'Access token',
  'Marcadopago Information' => 'Marcadopago Information',
  'Mercadopago Image' => 'Mercadopago Image',
  'Gateway' => 'Gateway',
);
