<?php
 return array (
  'Pay via Paymongo' => 'Pay via Paymongo',
  'Pay via Iyzico' => 'Pay via Iyzico',
  'Card Holder' => 'Card Holder',
  'Card Number' => 'Card Number',
  'Expiry' => 'Expiry',
  'CVC' => 'CVC',
  'MM/YY' => 'MM/YY',
  'Security Code' => 'Security Code',
  'Cardholder' => 'Cardholder',
  'Issuing bank' => 'Issuing bank',
  'Installments' => 'Installments',
  'Document type' => 'Document type',
  'Document number' => 'Document number',
  'Pay via Mercadopago' => 'Pay via Mercadopago',
  'Card holder email is required' => 'Card holder email is required',
  'Identification number is required' => 'Identification number is required',
);
