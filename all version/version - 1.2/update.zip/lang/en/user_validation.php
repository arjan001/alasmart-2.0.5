<?php
 return array (
  'Amount cannot be less than 100₱' => 'Amount cannot be less than 100₱',
  'Card is required' => 'Card is required',
  'CVC is required' => 'CVC is required',
  'Month is required' => 'Month is required',
  'Year is required' => 'Year is required',
);
 ?>
