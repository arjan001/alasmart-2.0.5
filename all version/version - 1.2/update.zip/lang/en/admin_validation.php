<?php
 return array (
  'Currency is required' => 'Currency is required',
  'Public key is required' => 'Public key is required',
  'Secret key is required' => 'Secret key is required',
  'Webhook is required' => 'Webhook is required',
  'API key is required' => 'API key is required',
  'Public key is required' => 'Public key is required',
  'Access token is required' => 'Access token is required',
);
