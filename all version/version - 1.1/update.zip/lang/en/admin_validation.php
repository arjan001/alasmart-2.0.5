<?php
 return array (
  'Country code is required' => 'Country code is required',
  'Country code already exist' =>'Country code already exist',
  'Currency code is required' =>'Currency code is required',
  'Currency code already exist' =>'Currency code already exist',
  'You can not delete this currency. Because there are one or more payment method has been created in this currency.' => 'You can not delete this currency. Because there are one or more payment method has been created in this currency.',
);
 ?>
